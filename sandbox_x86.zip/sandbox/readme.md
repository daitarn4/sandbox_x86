# ===========================================
# SHORT SANDBOX GUIDE
# ===========================================

This is a short guide to this simple minimal ubuntu-based sandbox.



# ===========================================
# Structure of the sandbox
# ===========================================

The sandbox is organized as follows:
 sandbox/
  |
  +---- bin/
  |      |
  |      +--- build.sh      this script launches the container-building process
  |      |
  |      +--- run.sh        this script uses the info in the docker-compose.yaml to launch the sandbox
  |      |
  |      +--- cleanup.sh    this script is used to remove all the instances associated to the sandbox (container, images)
  |
  +---- config/
  |      |
  |      +--- motd          contains the --message of the day-- shown through ssh-connection
  |      |
  |      +--- sshd_config   contains the configuration for the ssh-daemon loaded during the building process
  |
  +---- dockerfile.sandbox  contains the receipt for building the sandbox container (by means docker engine)
  |
  +---- docker-compose.yaml contains the commands for booting up the sandbox service
  |
  +---- storage/            it can be used to share data between sandbox and host machine 



 
# ===========================================
# Before starting ...
# ===========================================

Before running the building process, it is important to setting up the name of the user in the dockerfile.sandbox
and in the docker-compose.yaml as follows:

1) in dockerfile.sandbox: change the value associated to the ENV USER_SANDBOX environmental variable
2) in docker-compose.yaml: in line 10, the path contains the name of the user specified in the dockerfile.sandbox. So
   change it accordingly

Other changes that can be done are in the two files related to the exposed ip-port for the SSH service. By default, 
the port is set to 9876




# ===========================================
# Building and running sandbox
# ===========================================

In order to run the sandbox, run the following steps (assuming the user is set to gandalf):

1) cd bin && ./build.sh
2) ./run.sh 
3) open a second terminal and connect to the sandbox via ssh:
   ssh gandalf@<IP_ADDRESS> -p9876
   enter gandalf as the password
   <IP_ADDRESS> it is in the same subnet (e.g., 172.20.0.1) of the bridge created, i.e., 172.20.0.2
4) inside the sandbox, change the owner of the devel folder to gandalf (otherwise it will be not possible to 
   write inside the folder that is also binded with the --storage-- folder on the host machine)  
